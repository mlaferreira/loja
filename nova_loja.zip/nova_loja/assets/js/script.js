$( function() {
    $( "#slider-range" ).slider({
      range: true,
      min: 0,
      max: maxsLider,
      values: [$('#slider0').val(), $('#slider1').val()],
      slide: function( event, ui ) {
        $( "#amount" ).val( "R$" + ui.values[ 0 ] + " - R$" + ui.values[ 1 ] );
      },
      change: function(event, ui){
        $('#slider'+ui.handleIndex).val(ui.value);
        $('.filterarea form').submit();
      }
    });
    $( "#amount" ).val( "R$" + $( "#slider-range" ).slider( "values", 0 ) +
      " - R$" + $( "#slider-range" ).slider( "values", 1 ) );


      $('.filterarea').find('input').on('change', function(){
          $('.filterarea form').submit();
      });

    $('.btn-mais').on('click', function (e) {
      e.preventDefault();
       var qt = parseInt($('#qt').val());
       qt = qt + 1;
       $('#qt').val(qt);
    });

    $('.btn-menos').on('click', function (e) {
      e.preventDefault();
      var  qt = parseInt($('#qt').val());
      if(qt-1 >= 1){
        qt = qt - 1;
      }
      $('#qt').val(qt);
      
    });

    $('.photos-slider a').on('click', function(e){
      e.preventDefault();
      var url = $(this).find('img').attr('src');
      $('.photo-destaque').find('img').attr('src', url);
    });




} );