<div class="row pagina-product">
    <div class="col-sm-6 pagina-product-photo">
        <div class="box-galeira">
            <div class="photo-destaque">
                <img src="<?=BASE_URL;?>media/products/<?=$product_images[0]['url'];?>" alt="<?=$product_info['name'];?>">
            </div>
            <div class="photos-slider">
                <?php foreach($product_images as $img):?>
                <a href=""><img src="<?=BASE_URL;?>media/products/<?=$img['url'];?>" alt="<?=$product_info['name'];?>"></a>
                <?php endforeach;?>              
            </div>
        </div>

    </div>
    <div class="col-sm-6 pagina-product-info">
        <h2><?=$product_info['name'];?></h2>
        <div class="row pagina-product-avalia">
            <div class="col-sm-6 marca">
               <small><strong>Marca: </strong><?= $product_info['brand_name'];?></small><br/>
            </div>
            <div class="col-sm-6 estrelas">
                <small><strong>Avaliações: </strong>
                    <?php if($product_info['rating'] != '0'):?>
                        <?php for($i=0;$i<intval($product_info['rating']);$i++):?>
                            <img src="<?=BASE_URL;?>assets/images/star.png" width="15px" />
                        <?php endfor;?>
                    <?php endif;?>
                </small>
            </div>
        </div>  
        <p><strong>Descrição:</strong><br/>
        <?=$product_info['description'];?>
        </p>

        <div class="row pagina-product-price">
            <div class="col-sm-6">
                <small>DE: R$ <?=number_format($product_info['price_from'], '2', ',', '.');?></small>
            </div>
            <div class="col-sm-6">
                <span>POR: R$ <?=number_format($product_info['price'], '2', ',', '.');?></span>
            </div>
        </div>
        <div class="row pagina-product-ad-carrinho">
            <div class="col-sm-12">
                <form action="">
                    <div class="buttons">
                        <button class="btn-menos">-</button>
                        <input type="text" name="qt" value="1" id="qt" disabled />
                        <button class="btn-mais">+</button>
                    </div>
                    <div class="button-btn">
                        <a href="" class="btn"><?php $this->lang->get('ADD_TO_CART');?></a>
                    </div>
                </form>
            </div>            
          
        </div>
       
    </div>

   
</div>
<hr>
<div class="row line-options">
    <div class="col-sm-6">
        <h3 class="title"><strong><?php $this->lang->get('SPECIFICATIONS');?>:</h3>
            <?php foreach($product_options as $op):?>
                <p><strong><?=$op['name'];?></strong>: <?=$op['value'];?></p>
            <?php endforeach;?>
     </div>
    <div class="col-sm-6 review">
        <h3 class="title"><strong><?php $this->lang->get('REVIEW');?>:</h3>
        <?php foreach($product_rate as $rates):?>           
            <blockquote>
            <strong><?=$rates['user_name'];?></strong>:<br/>
            avaliação: 
            <?php for($i=0;$i<intval($rates['points']);$i++):?>
                <img src="<?=BASE_URL;?>assets/images/star.png" width="15px" />
            <?php endfor;?><br/>            
                "<?=$rates['comment'];?>"
            </blockquote>
            
        <?php endforeach;?>


    </div>
</div>