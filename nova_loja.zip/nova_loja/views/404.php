<h1>Ops! Página Não Encontrada.</h1>
    <p>Desculpe, não conseguimos encontrar a página que você está procurando. Pode ter sido removida, ter mudado de nome, ou estar temporariamente indisponível.</p>
    <p><a href="/">Clique aqui</a> para voltar à página inicial.</p>