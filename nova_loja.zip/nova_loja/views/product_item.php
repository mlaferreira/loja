<div class="product_item">
    <a href="<?=BASE_URL;?>product/open/<?=$id;?>">
        <div class="product_tags">
            <?php if($sale == '1'):?>
                <span class="product_tag product_tag_red"><?php $this->lang->get('SALE');?></span>
            <?php endif;?>
            <?php if($bestseller == '1'):?>
                <span class="product_tag product_tag_green"><?php $this->lang->get('BESTSELLER');?></span>
            <?php endif;?>
            <?php if($new_product == '1'):?>
                <span class="product_tag product_tag_blue"><?php $this->lang->get('NEW');?></span>
            <?php endif;?>
                
                
                
                      
        </div>
        <div class="product_image">
            <img src="<?=BASE_URL;?>media/products/<?php echo $images[0]['url'];?>" alt="" width="100%" />
        </div>
        <div class="product_name">
        <h2><?php echo $name;?></h2>
        </div>
        <div class="product_brand">
            <span><?php echo $brand_name;?></span>
            <small><strong>Avaliações: </strong>
                <?php if($rating!= '0'):?>
                    <?php for($i=0;$i<intval($rating);$i++):?>
                        <img src="<?=BASE_URL;?>assets/images/star.png" width="15px" />
                    <?php endfor;?>
                <?php endif;?>
            </small>
        </div>
        <div class="product_price_from">
            <small><?php 
            if($price_from != '0'){
                echo 'R$'.number_format($price_from, 2);

            }
            ?>
            </small>
            <strong>R$ <?php echo number_format($price, 2, ',', '.');?></strong>
        </div>
    </a>   
</div>