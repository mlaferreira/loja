<h1>Você está procurando por: "<?=$searchTerm;?>"</h1>

<div class="row">
<?php
    $i = 0; 
?>
<?php foreach($list as $key => $product_item) :?>
    <div class="col-sm-4">
        <?php $this->loadView('product_item', $product_item);?>
    </div>
    <?php
    if($i >= 2){
        $i = 0;
        echo '</div><div class="row">';
    }else{
        $i++;
    }
    
    ?>
<?php endforeach;?>
</div>
<div class="pagination">
    <?php for($i=1; $i<=$numberOfPage; $i++):?>
        <a href="<?php echo BASE_URL;?>?<?php $pag_array = $_GET;$pag_array['p'] = $i;echo http_build_query($pag_array);?>"><div class="paginationItem <?php echo ($currentPage == $i)?'pag_active':'';?>"><?=$i;?></div></a>   
    <?php endfor;?>
</div>

  